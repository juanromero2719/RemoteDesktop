/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

/**
 *
 * @author wrydmoon
 */
public class Start {
    
    public static void main(String[] args){
        
	SetPassword frame1= new SetPassword();
	frame1.setSize(300,80); 				
	frame1.setLocation(500,300);
	frame1.setVisible(true);
        
    }    
}
